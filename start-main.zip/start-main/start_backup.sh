#!/bin/bash
echo "GitHub Repositories worden geback-upt..."
python3 github_backup.py
echo "Klaar!"
read -p "Druk op Enter om af te sluiten..."
