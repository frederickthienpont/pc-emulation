import requests

# Vervang door je persoonlijke GitHub access token
GITHUB_TOKEN = 'jouw_github_token'

headers = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github+json'
}

# 1. Ophalen van alle ongelezen notificaties
response = requests.get(
    'https://api.github.com/notifications',
    headers=headers
)
notifications = response.json()

# 2. Elke notificatie als gelezen markeren
for notification in notifications:
    thread_id = notification['id']
    mark_url = f'https://api.github.com/notifications/threads/{thread_id}'
    mark_response = requests.patch(mark_url, headers=headers)
    if mark_response.status_code == 205:
        print(f"Notificatie {thread_id} is als gelezen gemarkeerd.")
    else:
        print(f"Fout bij notificatie {thread_id}: {mark_response.status_code}")

print("Klaar!")
