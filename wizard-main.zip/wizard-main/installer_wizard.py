import os
import shutil

# List of temporary file paths
temp_files = [
    r"c:\Users\frederick thienpont\AppData\Local\Temp\c6d69e8f-9ecb-4881-9feb-f13b67b6b8ff.tmp",
    r"c:\Users\frederick thienpont\AppData\Local\Temp\C9DF.tmp",
    r"c:\Users\frederick thienpont\AppData\Local\Temp\CFG6D86.tmp",
    r"c:\Users\frederick thienpont\AppData\Local\Temp\CFG79D4.tmp",
    # Add the rest of the file paths here...
]

def delete_temp_files():
    print("\nStep 1: Cleaning up temporary files...")
    for file_path in temp_files:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"Deleted: {file_path}")
            else:
                print(f"File not found: {file_path}")
        except Exception as e:
            print(f"Error deleting {file_path}: {e}")
    print("Temporary file cleanup complete.\n")

def installation_wizard():
    print("Welcome to the Installation Wizard!")
    print("This wizard will guide you through the installation process.\n")

    # Step 1: Confirm cleanup
    choice = input("Would you like to clean up temporary files before installation? (yes/no): ").strip().lower()
    if choice == "yes":
        delete_temp_files()
    else:
        print("Skipping temporary file cleanup.\n")

    # Step 2: Installation process
    print("Step 2: Installing the application...")
    # Simulate installation steps
    try:
        print("Copying files...")
        # Simulate file copying (replace with actual logic if needed)
        print("Setting up configurations...")
        # Simulate configuration setup
        print("Installation complete!")
    except Exception as e:
        print(f"An error occurred during installation: {e}")

    print("\nThank you for using the Installation Wizard!")

if __name__ == "__main__":
    installation_wizard()
