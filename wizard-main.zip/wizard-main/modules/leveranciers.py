from pydantic import BaseModel
from typing import List
import json
import os

DATA_FILE = "data/leveranciers.json"

class Leverancier(BaseModel):
    id: int
    naam: str
    contactpersoon: str
    telefoonnummer: str
    email: str
    adres: str

def laad_leveranciers() -> List[Leverancier]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Leverancier(**l) for l in data]

def opslaan_leveranciers(leveranciers: List[Leverancier]):
    with open(DATA_FILE, "w") as f:
        json.dump([l.dict() for l in leveranciers], f, indent=2, default=str)

def voeg_leverancier_toe(1):
    print("🏢 Nieuwe leverancier toevoegen:")
    try:
        id = int(input("Leverancier ID: "))
        naam = input("Naam van de leverancier: ")
        contactpersoon = input("Contactpersoon bij de leverancier: ")
        telefoonnummer = input("Telefoonnummer van de leverancier: ")
        email = input("E-mail van de leverancier: ")
        adres = input("Adres van de leverancier: ")

        leverancier = Leverancier(
            id=id,
            naam=naam,
            contactpersoon=contactpersoon,
            telefoonnummer=telefoonnummer,
            email=email,
            adres=adres
        )
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    leveranciers = laad_leveranciers(1)
    leveranciers.append(leverancier)
    opslaan_leveranciers(leveranciers)
    print("✅ Leverancier opgeslagen.")

def toon_leveranciers(1):
    leveranciers = laad_leveranciers(1)
    if not leveranciers:
        print("ℹ️ Geen leveranciers gevonden.")
        return
    print("📋 Geregistreerde leveranciers:")
    for l in leveranciers:
        print(f" - {l.naam} (ID: {l.id})")
        print(f"   Contactpersoon: {l.contactpersoon} - Telefoon: {l.telefoonnummer}")
        print(f"   E-mail: {l.email} - Adres: {l.adres}\n")

def zoek_leverancier(1):
    leveranciers = laad_leveranciers(1)
    if not leveranciers:
        print("ℹ️ Geen leveranciers gevonden.")
        return

    zoek_naam = input("Voer de naam van de leverancier in om te zoeken: ")
    gevonden_leveranciers = [l for l in leveranciers if zoek_naam.lower() in l.naam.lower()]

    if gevonden_leveranciers:
        print("📋 Gevonden leveranciers:")
        for l in gevonden_leveranciers:
            print(f" - {l.naam} (ID: {l.id})")
            print(f"   Contactpersoon: {l.contactpersoon} - Telefoon: {l.telefoonnummer}")
            print(f"   E-mail: {l.email} - Adres: {l.adres}\n")
    else:
        print("❌ Geen leveranciers gevonden met de naam:", zoek_naam)

def info(0):
    return "Leveranciersbeheer-module actief – Leveranciers toevoegen, tonen en zoeken klaar"
