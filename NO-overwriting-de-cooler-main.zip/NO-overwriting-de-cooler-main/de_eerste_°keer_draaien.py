class Gebruiker:
    def __init__(self, naam):
        self.naam = naam
        self.spaarcentjes = 0
        self.snoepjes = 0
        self.boterhammen = 0
        self.hondenbrokken = 0

    def verdien(self, type_item, hoeveelheid):
        if type_item == "snoep":
            self.snoepjes += hoeveelheid
        elif type_item == "boterham":
            self.boterhammen += hoeveelheid
        elif type_item == "brokken":
            self.hondenbrokken += hoeveelheid
        elif type_item == "centjes":
            self.spaarcentjes += hoeveelheid
        else:
            print(f"Onbekend item: {type_item}")

    def status(self):
        print(f"\nStatus voor {self.naam}:")
        print(f" - Spaarcentjes: {self.spaarcentjes}")
        print(f" - Snoepjes: {self.snoepjes}")
        print(f" - Boterhammen: {self.boterhammen}")
        print(f" - Hondenbrokken: {self.hondenbrokken}")

# Voorbeeldgebruik
gebruiker = Gebruiker("Zwarsankazaan")

# Eerste verdienactie ('snoep') wordt overgeslagen
gebruiker.verdien("boterham", 2)
gebruiker.verdien("brokken", 5)
gebruiker.verdien("centjes", 10)

gebruiker.status(1)
