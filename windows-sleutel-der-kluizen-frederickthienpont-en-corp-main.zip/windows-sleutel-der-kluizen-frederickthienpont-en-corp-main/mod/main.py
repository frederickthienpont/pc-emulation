from modules import modeling

# Binnen de loop:
elif keuze == "9":
    modeling.voeg_model_toe(1)
elif keuze == "10":
    modeling.toon_modellen(1)
print("\y[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[0] Afsluiten")
from modules import defense

# Binnen de loop:
elif keuze == "11":
    defense.voeg_materieel_toe(1)
elif keuze == "12":
    defense.toon_materieel(1)
print("\n[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[0] Afsluiten")
