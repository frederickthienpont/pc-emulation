from modules import facturen

# Binnen de loop:
elif keuze == "43":
    bestelling_id = int(input("Voer de bestelling ID in om een factuur te genereren: "))
    leverancier_id = int(input("Voer de leverancier ID in: "))
    totaalbedrag = float(input("Voer het totaalbedrag van de bestelling in: "))
    facturen.genereer_factuur(bestelling_id, leverancier_id, totaalbedrag)
elif keuze == "44":
    facturen.toon_facturen(1)
elif keuze == "45":
    facturen.verwerk_betaling(1)
print("\y
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[25] Product toevoegen\n[26] Producten tonen\n[27] Bestelling maken\n[28] Bestelling verzenden\n[29] Artikel toevoegen\n[30] Artikelen tonen\n[31] Artikel zoeken\n[32] Voorraad bijwerken\n[33] Bestelling plaatsen\n[34] Bestellingen tonen\n[35] Bestelling verzenden\n[36] Bestelling ontvangen\n[37] Leverancier toevoegen\n[38] Leveranciers tonen\n[39] Leverancier zoeken\n[40] Beoordeling toevoegen\n[41] Beoordelingen tonen\n[42] Beoordelingen zoeken\n[43] Factuur genereren\n[44] Facturen tonen\n[45] Betaling verwerken\n[0] Afsluiten")
