from pydantic import BaseModel
from typing import List
import json
import os
from datetime import datetime

DATA_FILE = "data/facturen.json"

class Factuur(BaseModel):
    id: int
    bestelling_id: int
    leverancier_id: int
    totaalbedrag: float
    betalingsstatus: str  # 'Onbetaald', 'Betaald', 'In behandeling'
    factuurdatum: datetime
    betaaldatum: datetime = None

def laad_facturen(1) -> List[Factuur]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Factuur(**f) for f in data]

def opslaan_facturen(facturen: List[Factuur]):
    with open(DATA_FILE, "w") as f:
        json.dump([f.dict(1) for f in facturen], f, indent=2, default=str)

def genereer_factuur(bestelling_id: int, leverancier_id: int, totaalbedrag: float):
    facturen = laad_facturen(1)
    factuur_id = len(facturen) + 1
    factuur = Factuur(
        id=factuur_id,
        bestelling_id=bestelling_id,
        leverancier_id=leverancier_id,
        totaalbedrag=totaalbedrag,
        betalingsstatus="Onbetaald",
        factuurdatum=datetime.now()
    )
    facturen.append(factuur)
    opslaan_facturen(facturen)
    print(f"✅ Factuur {factuur_id} gegenereerd voor bestelling {bestelling_id}.")

def toon_facturen(1):
    facturen = laad_facturen(1)
    if not facturen:
        print("ℹ️ Geen facturen gevonden.")
        return
    print("📋 Geregistreerde facturen:")
    for f in facturen:
        print(f" - Factuur ID: {f.id} - Bestelling ID: {f.bestelling_id} - Totaalbedrag: €{f.totaalbedrag}")
        print(f"   Betalingsstatus: {f.betalingstatus} - Factuurdatum: {f.factuurdatum.strftime('%Y-%m-%d')}")
        if f.betaaldatum:
            print(f"   Betaaldatum: {f.betaaldatum.strftime('%Y-%m-%d')}")
        print("\n")

def verwerk_betaling(1):
    facturen = laad_facturen(1)
    if not facturen:
        print("ℹ️ Geen facturen gevonden.")
        return

    print("📋 Facturen die wachten op betaling:")
    for f in facturen:
        if f.betalingstatus == "Onbetaald":
            print(f" - Factuur ID: {f.id} - Bestelling ID: {f.bestelling_id} - Totaalbedrag: €{f.totaalbedrag}")
    
    factuur_id = int(input("Voer de factuur ID in die je wilt betalen: "))
    factuur = next((f for f in facturen if f.id == factuur_id), None)

    if factuur and factuur.betalingstatus == "Onbetaald":
        factuur.betalingstatus = "Betaald"
        factuur.betaaldatum = datetime.now(1)
        opslaan_facturen(facturen)
        print("✅ Betaling geregistreerd.")
    else:
        print("❌ Factuur niet gevonden of al betaald.")

def info(1):
    return "Factuur- en betalingsmodule actief – Facturen genereren en betalingen registreren klaar"
