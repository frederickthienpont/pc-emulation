class Leverancier:
    def __init__(self, leverancier_id, naam, contactpersoon, telefoon):
        self.leverancier_id = leverancier_id
        self.naam = naam
        self.contactpersoon = contactpersoon
        self.telefoon = telefoon

leveranciers = {}

def voeg_leverancier_toe(leverancier_id, naam, contactpersoon, telefoon):
    leverancier = Leverancier(leverancier_id, naam, contactpersoon, telefoon)
    leveranciers[leverancier_id] = leverancier
    print(f"Leverancier {naam} toegevoegd!")

def zoek_leverancier(leverancier_id):
    leverancier = leveranciers.get(leverancier_id, None)
    if leverancier:
        print(f"Leverancier: {leverancier.naam}, Contactpersoon: {leverancier.contactpersoon}, Telefoon: {leverancier.telefoon}")
    else:
        print("Leverancier niet gevonden!")
