def toon_omzetgroei(omzet_data):
    # Veronderstel dat omzet_data een dictionary is met maandelijkse omzet
    omzetgroei = sorted(omzet_data.items())
    maanden, omzetten = zip(*omzetgroei)

    plt.plot(maanden, omzetten, marker='o', color='g', label="Omzetgroei")
    plt.xlabel('Maanden')
    plt.ylabel('Omzet in eenheden')
    plt.title('Omzetgroei')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.legend()
    plt.show()
