class MarketingCampagne:
    def __init__(self, campagne_id, naam, korting_percentage, startdatum, einddatum, actief):
        self.campagne_id = campagne_id
        self.naam = naam
        self.korting_percentage = korting_percentage
        self.startdatum = startdatum
        self.einddatum = einddatum
        self.actief = actief

campagnes = []

def voeg_campagne_toe(campagne_id, naam, korting_percentage, startdatum, einddatum):
    campagne = MarketingCampagne(campagne_id, naam, korting_percentage, startdatum, einddatum, actief=True)
    campagnes.append(campagne)
    print(f"Campagne '{naam}' toegevoegd!")

def toon_actieve_campagnes():
    actieve_campagnes = [campagne for campagne in campagnes if campagne.actief]
    if actieve_campagnes:
        for campagne in actieve_campagnes:
            print(f"Campagne: {campagne.naam}, Korting: {campagne.korting_percentage}%")
    else:
        print("Er zijn momenteel geen actieve campagnes.")
