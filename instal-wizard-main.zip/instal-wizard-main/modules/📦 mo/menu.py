def keuzemenu():
    while True:
        print("\n--- Keuzemenu ---")
        print("[1] Klant toevoegen")
        print("[2] Klant zoeken")
        print("[3] Bestelling toevoegen")
        print("[4] Betaling toevoegen")
        print("[5] Verkoopanalyse tonen")
        print("[6] Marketingcampagne toevoegen")
        print("[7] Actieve campagnes tonen")
        print("[8] Producten tonen")
        print("[9] Voorraad bijwerken")
        print("[10] Klantbeoordeling toevoegen")
        print("[11] Klantbeoordelingen tonen")
        print("[12] Rapporten genereren")
        print("[13] Betaling verwerken via PayPal")
        print("[14] Betaling verwerken via Stripe")
        print("[15] Geavanceerde verkoopanalyse")
        print("[0] Afsluiten")

        keuze = input("Maak een keuze: ")

        if keuze == '1':
            # Klant toevoegen
            pass
        elif keuze == '2':
            # Klant zoeken
            pass
        elif keuze == '3':
            # Bestelling toevoegen
            pass
        elif keuze == '4':
            # Betaling toevoegen
            pass
        elif keuze == '5':
            # Verkoopanalyse tonen
            pass
        elif keuze == '6':
            # Marketingcampagne toevoegen
            pass
        elif keuze == '7':
            # Actieve campagnes tonen
            pass
        elif keuze == '8':
            # Producten tonen
            pass
        elif keuze == '9':
            # Voorraad bijwerken
            pass
        elif keuze == '10':
            # Klantbeoordeling toevoegen
            pass
        elif keuze == '11':
            # Klantbeoordelingen tonen
            pass
        elif keuze == '12':
            # Rapporten genereren
            pass
        elif keuze == '13':
            # Betaling via PayPal
            pass
        elif keuze == '14':
            # Betaling via Stripe
            pass
        elif keuze == '15':
            # Geavanceerde verkoopanalyse
            pass
        elif keuze == '0':
            print("Afsluiten...")
            break
        else:
            print("Ongeldige keuze, probeer het opnieuw.")

# Start het keuzemenu
keuzemenu()
