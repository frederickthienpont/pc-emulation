from collections import defaultdict
import matplotlib.pyplot as plt

# Simulatie van verkoopdata (artikelen en hun verkopen)
verkoop_data = [
    {"artikel_id": 1, "aantal": 50, "datum": "2025-01-15"},
    {"artikel_id": 2, "aantal": 30, "datum": "2025-01-16"},
    {"artikel_id": 3, "aantal": 20, "datum": "2025-02-01"},
    {"artikel_id": 1, "aantal": 70, "datum": "2025-02-10"},
    # Voeg meer verkooprecords toe
]

def analyseer_populaire_producten():
    verkoop_totaal = defaultdict(int)

    for verkoop in verkoop_data:
        verkoop_totaal[verkoop["artikel_id"]] += verkoop["aantal"]

    populaire_producten = sorted(verkoop_totaal.items(), key=lambda x: x[1], reverse=True)
    print("\nPopulaire producten op basis van verkoop:")
    for artikel_id, aantal in populaire_producten:
        print(f"Artikel ID: {artikel_id}, Verkochte eenheden: {aantal}")

def verkoopgroei():
    maanden = defaultdict(int)
    for verkoop in verkoop_data:
        maand = verkoop["datum"][:7]  # Maand in 'YYYY-MM' formaat
        maanden[maand] += verkoop["aantal"]

    maanden_sorted = sorted(maanden.items())
    maanden_labels, maand_data = zip(*maanden_sorted)

    # Visualisatie van de verkoopgroei per maand
    plt.plot(maanden_labels, maand_data, marker='o', color='b', label="Verkoopgroei")
    plt.xlabel('Maanden')
    plt.ylabel('Verkochte eenheden')
    plt.title('Verkoopgroei per Maand')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.legend()
    plt.show()
