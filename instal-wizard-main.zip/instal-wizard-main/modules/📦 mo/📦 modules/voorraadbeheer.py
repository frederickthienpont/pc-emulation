class Product:
    def __init__(self, artikel_id, naam, voorraad, prijs):
        self.artikel_id = artikel_id
        self.naam = naam
        self.voorraad = voorraad
        self.prijs = prijs

producten = {}

def voeg_product_toe(artikel_id, naam, voorraad, prijs):
    product = Product(artikel_id, naam, voorraad, prijs)
    producten[artikel_id] = product
    print(f"Product {naam} toegevoegd met Artikel ID: {artikel_id}")

def controleer_voorraad(artikel_id):
    product = producten.get(artikel_id, None)
    if product:
        print(f"Product: {product.naam}, Voorraad: {product.voorraad}, Prijs: {product.prijs}")
    else:
        print("Product niet gevonden!")

def update_voorraad(artikel_id, nieuwe_voorraad):
    product = producten.get(artikel_id, None)
    if product:
        product.voorraad = nieuwe_voorraad
        print(f"Voorraad van {product.naam} bijgewerkt naar {nieuwe_voorraad}.")
    else:
        print("Product niet gevonden!")
