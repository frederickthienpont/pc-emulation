class Klant:
    def __init__(self, klant_id, naam, email, telefoon, adres):
        self.klant_id = klant_id
        self.naam = naam
        self.email = email
        self.telefoon = telefoon
        self.adres = adres
        self.bestellingen = []  # Een lijst van bestellingen die de klant heeft geplaatst

    def voeg_bestelling_toe(self, bestelling):
        self.bestellingen.append(bestelling)

class Bestelling:
    def __init__(self, bestelling_id, datum, totaalbedrag):
        self.bestelling_id = bestelling_id
        self.datum = datum
        self.totaalbedrag = totaalbedrag

# Klantenbestand simulatie
klanten = {}

def voeg_klant_toe(klant_id, naam, email, telefoon, adres):
    klant = Klant(klant_id, naam, email, telefoon, adres)
    klanten[klant_id] = klant
    print(f"Klant {naam} toegevoegd!")

def zoek_klant(klant_id):
    klant = klanten.get(klant_id, None)
    if klant:
        print(f"Gegevens van klant {klant.naam}:")
        print(f"Email: {klant.email}, Telefoon: {klant.telefoon}, Adres: {klant.adres}")
        print("Bestelgeschiedenis:")
        for bestelling in klant.bestellingen:
            print(f"Bestelling ID: {bestelling.bestelling_id}, Datum: {bestelling.datum}, Totaalbedrag: {bestelling.totaalbedrag}")
    else:
        print("Klant niet gevonden!")

def voeg_bestelling_toe_aan_klant(klant_id, bestelling_id, datum, totaalbedrag):
    klant = klanten.get(klant_id, None)
    if klant:
        bestelling = Bestelling(bestelling_id, datum, totaalbedrag)
        klant.voeg_bestelling_toe(bestelling)
        print(f"Bestelling {bestelling_id} toegevoegd aan klant {klant.naam}")
    else:
        print("Klant niet gevonden!")
