class Betaling:
    def __init__(self, betaling_id, klant_id, bedrag, datum, status):
        self.betaling_id = betaling_id
        self.klant_id = klant_id
        self.bedrag = bedrag
        self.datum = datum
        self.status = status  # 'betaald', 'open', 'geannuleerd'

betalingen = []

def registreer_betaling(betaling_id, klant_id, bedrag, datum, status):
    betaling = Betaling(betaling_id, klant_id, bedrag, datum, status)
    betalingen.append(betaling)
    print(f"Betaling {betaling_id} van klant {klant_id} geregistreerd.")

def controleer_betaling(betaling_id):
    betaling = next((b for b in betalingen if b.betaling_id == betaling_id), None)
    if betaling:
        print(f"Betaling ID: {betaling.betaling_id}, Klant ID: {betaling.klant_id}, Bedrag: {betaling.bedrag}, Status: {betaling.status}")
    else:
        print("Betaling niet gevonden.")
