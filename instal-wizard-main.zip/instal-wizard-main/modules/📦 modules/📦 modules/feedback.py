class Beoordeling:
    def __init__(self, klant_id, artikel_id, score, opmerking):
        self.klant_id = klant_id
        self.artikel_id = artikel_id
        self.score = score  # Score tussen 1 en 5
        self.opmerking = opmerking

# Feedback en beoordelingen
beoordelingen = []

def voeg_beoordeling_toe(klant_id, artikel_id, score, opmerking):
    beoordeling = Beoordeling(klant_id, artikel_id, score, opmerking)
    beoordelingen.append(beoordeling)
    print(f"Beoordeling toegevoegd voor Artikel ID: {artikel_id} door Klant ID: {klant_id}")

def toon_beoordelingen(artikel_id):
    artikel_beoordelingen = [b for b in beoordelingen if b.artikel_id == artikel_id]
    if artikel_beoordelingen:
        for beoordeling in artikel_beoordelingen:
            print(f"Klant ID: {beoordeling.klant_id} | Score: {beoordeling.score} | Opmerking: {beoordeling.opmerking}")
    else:
        print(f"Er zijn nog geen beoordelingen voor Artikel ID: {artikel_id}")
